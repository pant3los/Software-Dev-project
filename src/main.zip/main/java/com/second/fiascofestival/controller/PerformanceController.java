package com.second.fiascofestival.controller;

import com.second.fiascofestival.model.Performance;
import com.second.fiascofestival.service.PerformanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/performances")
public class PerformanceController {

    @Autowired
    private PerformanceService performanceService;

    // Create a new performance
    @PostMapping
    public ResponseEntity<Performance> createPerformance(@RequestBody Performance performance) {
        return ResponseEntity.ok(performanceService.createPerformance(performance));
    }

    // Update an existing performance
    @PutMapping("/{id}")
    public ResponseEntity<Performance> updatePerformance(@PathVariable String id, @RequestBody Performance updatedPerformance) {
        return ResponseEntity.ok(performanceService.updatePerformance(id, updatedPerformance));
    }

    // Get all performances by festival ID
    @GetMapping("/festival/{festivalId}")
    public ResponseEntity<List<Performance>> getPerformancesByFestival(@PathVariable String festivalId) {
        return ResponseEntity.ok(performanceService.getPerformancesByFestival(festivalId));
    }

    // Delete a performance by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePerformance(@PathVariable String id) {
        performanceService.deletePerformance(id);
        return ResponseEntity.noContent().build();
    }



}
